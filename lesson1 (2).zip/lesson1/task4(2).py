print('4th program')

# Given floating point numbers
num1 = 13.42
num2 = 42.13

# Extract the integer and fractional parts
int_part1 = int(num1)
frac_part1 = int((num1 * 100) % 100)

int_part2 = int(num2)
frac_part2 = int((num2 * 100) % 100)

# Check the condition
result = int_part1 == frac_part2 or int_part2 == frac_part1

print(result)  # Expected result: True