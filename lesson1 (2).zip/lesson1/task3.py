print('3d program')
print((1234%1004//10)+(5678%5008//10))